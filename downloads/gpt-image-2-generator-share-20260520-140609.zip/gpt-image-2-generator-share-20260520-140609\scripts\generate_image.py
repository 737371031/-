from __future__ import annotations

import argparse
import base64
import binascii
from dataclasses import dataclass
import json
import mimetypes
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable


ROOT_DIR = Path(__file__).resolve().parents[1]
TOKEN_FILE = ROOT_DIR / "config" / "token.txt"
DEFAULT_API_BASE_URL = "https://wuzuapi.com"
API_BASE_URL_ENV_VARS = (
    "GPT_IMAGE_2_API_BASE_URL",
    "WUZUAPI_API_BASE_URL",
    "WUZUAPI_BASE_URL",
    "APICODEX_API_BASE_URL",
    "APICODEX_BASE_URL",
)
MODEL = "gpt-image-2"
SUPPORTED_QUALITIES = ("1k", "2k", "4k")
DEFAULT_QUALITY = "2k"
QUALITY_LONG_EDGE = {
    "1k": 1024,
    "2k": 2048,
    "4k": 4096,
}
SUPPORTED_SIZES = (
    "1:1",
    "16:9",
    "9:16",
    "4:3",
    "3:4",
    "3:2",
    "2:3",
    "5:4",
    "4:5",
    "2:1",
    "1:2",
    "21:9",
    "9:21",
)
TOKEN_PLACEHOLDERS = {"YOUR_API_TOKEN_HERE", "<token>", "Bearer <token>"}
TOKEN_ENV_VARS = (
    "GPT_IMAGE_2_TOKEN",
    "WUZUAPI_API_KEY",
    "WUZUAPI_TOKEN",
    "APICODEX_API_KEY",
    "APICODEX_TOKEN",
    "CODEX_API_KEY",
    "OPENAI_API_KEY",
)
RETRYABLE_HTTP_STATUS_CODES = {502, 503, 504}
MAX_UPSTREAM_RETRIES = 2
RETRY_BACKOFF_SECONDS = 2.0


class ImageGenerationError(RuntimeError):
    pass


class UpstreamHTTPError(ImageGenerationError):
    def __init__(self, status_code: int, body: str, url: str, attempts: int = 1):
        self.status_code = status_code
        self.body = body
        self.url = url
        self.attempts = attempts
        super().__init__(format_http_error_message(status_code, body, url, attempts))


@dataclass(frozen=True)
class ImageInputFile:
    filename: str
    mime_type: str
    data: bytes


def normalize_token(raw_token: str) -> str:
    return raw_token.strip().removeprefix("Bearer ").strip()


def normalize_api_base_url(raw_url: str) -> str:
    value = raw_url.strip()
    if not value:
        return DEFAULT_API_BASE_URL
    if "://" not in value:
        value = f"https://{value}"
    return value.rstrip("/")


def get_api_base_url() -> str:
    default_normalized = normalize_api_base_url("")
    for env_name in API_BASE_URL_ENV_VARS:
        raw_value = os.environ.get(env_name, "")
        if raw_value.strip():
            return normalize_api_base_url(raw_value)
    return default_normalized


def build_api_url(path: str) -> str:
    return f"{get_api_base_url()}{path}"


def build_generations_api_url() -> str:
    return build_api_url("/v1/images/generations")


def build_edits_api_url() -> str:
    return build_api_url("/v1/images/edits")


def build_task_url(task_id: str) -> str:
    return build_api_url(f"/v1/tasks/{urllib.parse.quote(task_id)}")


def round_to_multiple(value: float, multiple: int = 8) -> int:
    rounded = int(round(value / multiple) * multiple)
    return max(multiple, rounded)


def resolve_size_value(size: str, quality: str) -> str:
    if size not in SUPPORTED_SIZES:
        raise ImageGenerationError(f"Unsupported size: {size}")
    if quality not in SUPPORTED_QUALITIES:
        raise ImageGenerationError(f"Unsupported quality: {quality}")

    width_ratio, height_ratio = (int(part) for part in size.split(":"))
    long_edge = QUALITY_LONG_EDGE[quality]
    if width_ratio >= height_ratio:
        width = long_edge
        height = round_to_multiple(long_edge * height_ratio / width_ratio)
    else:
        width = round_to_multiple(long_edge * width_ratio / height_ratio)
        height = long_edge
    return f"{width}x{height}"


def missing_token_message() -> str:
    env_list = ", ".join(TOKEN_ENV_VARS)
    return (
        f"No usable token found. Set one of these environment variables: {env_list}, "
        f"or fill {TOKEN_FILE}. Note: this tool targets the API gateway at {get_api_base_url()}, "
        "so a Codex/OpenAI key only works if your gateway accepts it."
    )


def load_token() -> str:
    file_lines: list[str] | None = None
    for env_name in TOKEN_ENV_VARS:
        token = normalize_token(os.environ.get(env_name, ""))
        if token and token not in TOKEN_PLACEHOLDERS:
            return token

    if not TOKEN_FILE.exists():
        raise ImageGenerationError(missing_token_message())

    file_lines = TOKEN_FILE.read_text(encoding="utf-8-sig").splitlines()

    for line in file_lines:
        value = line.strip()
        if value and not value.startswith("#"):
            token = normalize_token(value)
            if token in TOKEN_PLACEHOLDERS:
                raise ImageGenerationError(missing_token_message())
            return token

    # Be forgiving if a token was accidentally pasted onto the comment line.
    for line in file_lines:
        match = re.search(r"\bsk-[A-Za-z0-9._-]+\b", line)
        if match:
            token = normalize_token(match.group(0))
            if token and token not in TOKEN_PLACEHOLDERS:
                return token

    raise ImageGenerationError(missing_token_message())


def extract_error_message_from_body(body: str) -> str | None:
    if not body:
        return None
    try:
        payload = json.loads(body)
    except json.JSONDecodeError:
        compact = " ".join(body.split())
        return compact[:500] if compact else None

    if isinstance(payload, dict):
        error = payload.get("error")
        if isinstance(error, dict):
            message = error.get("message")
            if isinstance(message, str) and message.strip():
                return message.strip()
        message = payload.get("message")
        if isinstance(message, str) and message.strip():
            return message.strip()

    compact = " ".join(body.split())
    return compact[:500] if compact else None


def format_http_error_message(status_code: int, body: str, url: str, attempts: int = 1) -> str:
    detail = extract_error_message_from_body(body)
    attempt_text = f" after {attempts} attempts" if attempts > 1 else ""
    if status_code in RETRYABLE_HTTP_STATUS_CODES:
        prefix = f"Upstream API temporarily unavailable (HTTP {status_code}){attempt_text}"
    else:
        prefix = f"Upstream API returned HTTP {status_code}{attempt_text}"
    if detail:
        return f"{prefix}: {detail}"
    return f"{prefix}. URL: {url}"


def read_json_response(request: urllib.request.Request, timeout: int) -> dict[str, Any]:
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read().decode("utf-8")
    except urllib.error.HTTPError as error:
        body = error.read().decode("utf-8", errors="replace")
        raise UpstreamHTTPError(error.code, body, request.full_url) from error
    except urllib.error.URLError as error:
        raise ImageGenerationError(f"Network error: {error}") from error

    if not body:
        return {}
    try:
        return json.loads(body)
    except json.JSONDecodeError as error:
        raise ImageGenerationError(f"API returned non-JSON response: {body[:500]}") from error


def request_with_retries(request_factory: Callable[[], urllib.request.Request], timeout: int, url: str) -> dict[str, Any]:
    attempts = MAX_UPSTREAM_RETRIES + 1
    last_error: UpstreamHTTPError | None = None
    for attempt in range(1, attempts + 1):
        try:
            return read_json_response(request_factory(), timeout)
        except UpstreamHTTPError as error:
            last_error = error
            if error.status_code not in RETRYABLE_HTTP_STATUS_CODES or attempt >= attempts:
                break
            time.sleep(RETRY_BACKOFF_SECONDS * attempt)

    if last_error is None:
        raise ImageGenerationError(f"Request failed before an HTTP response was received: {url}")
    raise UpstreamHTTPError(last_error.status_code, last_error.body, url, attempts=attempts) from last_error


def request_json(method: str, url: str, token: str, payload: dict[str, Any] | None = None, timeout: int = 300) -> dict[str, Any]:
    data = None
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "User-Agent": "gpt-image-2-generator/1.0",
    }
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")

    def build_request() -> urllib.request.Request:
        return urllib.request.Request(url, data=data, headers=headers, method=method)

    return request_with_retries(build_request, timeout, url)


def request_multipart_json(
    url: str,
    token: str,
    fields: dict[str, Any],
    files: list[ImageInputFile],
    timeout: int = 300,
) -> dict[str, Any]:
    boundary = f"----gpt-image-2-{uuid.uuid4().hex}"
    body = bytearray()

    def add(value: str | bytes) -> None:
        if isinstance(value, str):
            body.extend(value.encode("utf-8"))
        else:
            body.extend(value)

    for name, value in fields.items():
        add(f"--{boundary}\r\n")
        add(f'Content-Disposition: form-data; name="{name}"\r\n\r\n')
        add(str(value))
        add("\r\n")

    for image_file in files:
        add(f"--{boundary}\r\n")
        add(
            'Content-Disposition: form-data; name="image[]"; '
            f'filename="{image_file.filename}"\r\n'
        )
        add(f"Content-Type: {image_file.mime_type}\r\n\r\n")
        add(image_file.data)
        add("\r\n")

    add(f"--{boundary}--\r\n")
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": f"multipart/form-data; boundary={boundary}",
        "Content-Length": str(len(body)),
        "User-Agent": "gpt-image-2-generator/1.0",
    }
    payload_bytes = bytes(body)

    def build_request() -> urllib.request.Request:
        return urllib.request.Request(url, data=payload_bytes, headers=headers, method="POST")

    return request_with_retries(build_request, timeout, url)


def safe_filename(filename: str, fallback: str, mime_type: str) -> str:
    candidate = re.sub(r"[^A-Za-z0-9._-]+", "_", Path(filename).name).strip("._")
    if not candidate:
        candidate = fallback
    if not Path(candidate).suffix:
        candidate += mimetypes.guess_extension(mime_type) or ".png"
    return candidate


def read_data_uri_image(value: str, index: int) -> ImageInputFile:
    match = re.match(r"^data:(?P<mime>image/[^;,]+)(?P<params>(?:;[^,]+)*),(?P<data>.+)$", value, flags=re.DOTALL)
    if not match or ";base64" not in match.group("params").lower():
        raise ImageGenerationError("Reference image data URI must be a base64 image")

    mime_type = match.group("mime")
    try:
        data = base64.b64decode(match.group("data"), validate=True)
    except (ValueError, binascii.Error) as error:
        raise ImageGenerationError("Reference image data URI contains invalid base64") from error
    return ImageInputFile(
        filename=safe_filename("", f"reference-{index}", mime_type),
        mime_type=mime_type,
        data=data,
    )


def download_reference_image(url: str, index: int, timeout: int) -> ImageInputFile:
    request = urllib.request.Request(url, headers={"User-Agent": "gpt-image-2-generator/1.0"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = response.read()
            content_type = response.headers.get("Content-Type")
    except urllib.error.HTTPError as error:
        body = error.read().decode("utf-8", errors="replace")
        raise ImageGenerationError(f"Reference image URL returned HTTP {error.code}: {body[:500]}") from error
    except urllib.error.URLError as error:
        raise ImageGenerationError(f"Reference image URL could not be downloaded: {error}") from error

    mime_type = (content_type or "").split(";")[0].strip().lower()
    if not mime_type.startswith("image/"):
        mime_type = mimetypes.guess_type(urllib.parse.urlparse(url).path)[0] or "image/png"
    filename = safe_filename(Path(urllib.parse.urlparse(url).path).name, f"reference-{index}", mime_type)
    return ImageInputFile(filename=filename, mime_type=mime_type, data=data)


def read_local_reference_image(image_ref: str, index: int) -> ImageInputFile:
    value = image_ref.strip()
    path = Path(value).expanduser()
    if not path.is_absolute():
        cwd_path = Path.cwd() / path
        root_path = ROOT_DIR / path
        path = cwd_path if cwd_path.exists() else root_path

    if not path.exists():
        raise ImageGenerationError(f"Reference image not found: {image_ref}")

    mime_type = mimetypes.guess_type(str(path))[0] or "image/png"
    return ImageInputFile(
        filename=safe_filename(path.name, f"reference-{index}", mime_type),
        mime_type=mime_type,
        data=path.read_bytes(),
    )


def image_ref_to_input_file(image_ref: str, index: int, timeout: int) -> ImageInputFile:
    value = image_ref.strip()
    lowered = value.lower()
    if lowered.startswith("data:"):
        return read_data_uri_image(value, index)
    if lowered.startswith(("http://", "https://")):
        return download_reference_image(value, index, timeout)
    return read_local_reference_image(value, index)


def save_json(path: Path, data: dict[str, Any]) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    for index in range(2, 1000):
        candidate = path.with_name(f"{path.stem}-{index}{path.suffix}")
        if not candidate.exists():
            return candidate
    raise ImageGenerationError(f"Cannot create unique output path for {path}")


def save_b64_image(image_b64: str, output_dir: Path, stem: str, index: int, mime: str | None = None) -> Path:
    extension = mimetypes.guess_extension(mime or "image/png") or ".png"
    output_path = unique_path(output_dir / f"{stem}-{index}{extension}")
    output_path.write_bytes(base64.b64decode(image_b64))
    return output_path


def save_data_uri(data_uri: str, output_dir: Path, stem: str, index: int) -> Path:
    match = re.match(r"^data:(?P<mime>[^;]+);base64,(?P<data>.+)$", data_uri, flags=re.DOTALL)
    if not match:
        raise ImageGenerationError("Unsupported data URI image format")
    return save_b64_image(match.group("data"), output_dir, stem, index, match.group("mime"))


def extract_b64_items(data: Any) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            if isinstance(value.get("b64_json"), str):
                items.append(value)
                return
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    visit(data)
    return items


def extract_image_values(data: Any) -> list[str]:
    values: list[str] = []

    def add(value: Any) -> None:
        if isinstance(value, str) and value.startswith(("http://", "https://", "data:image/")):
            values.append(value)
        elif isinstance(value, list):
            for item in value:
                add(item)

    candidates = []
    if isinstance(data, dict):
        candidates.append(data.get("url"))
        nested_data = data.get("data")
        if isinstance(nested_data, list):
            candidates.extend(item.get("url") for item in nested_data if isinstance(item, dict))
        if isinstance(nested_data, dict):
            result = nested_data.get("result")
            if isinstance(result, dict):
                images = result.get("images")
                if isinstance(images, list):
                    candidates.extend(item.get("url") for item in images if isinstance(item, dict))
                candidates.append(result.get("url"))
        result = data.get("result")
        if isinstance(result, dict):
            images = result.get("images")
            if isinstance(images, list):
                candidates.extend(item.get("url") for item in images if isinstance(item, dict))

    for candidate in candidates:
        add(candidate)
    return values


def extract_task_id(data: dict[str, Any]) -> str | None:
    for key in ("task_id", "id"):
        value = data.get(key)
        if isinstance(value, str) and value:
            return value

    nested_data = data.get("data")
    if isinstance(nested_data, dict):
        for key in ("task_id", "id"):
            value = nested_data.get(key)
            if isinstance(value, str) and value:
                return value
    return None


def get_task_status(task: dict[str, Any]) -> str | None:
    nested_data = task.get("data")
    if isinstance(nested_data, dict) and isinstance(nested_data.get("status"), str):
        return nested_data["status"]
    status = task.get("status")
    return status if isinstance(status, str) else None


def get_task_error(task: dict[str, Any]) -> str:
    nested_data = task.get("data")
    error = nested_data.get("error") if isinstance(nested_data, dict) else task.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or error)
    if error:
        return str(error)
    return "task failed"


def guess_download_extension(url: str, content_type: str | None) -> str:
    suffix = Path(urllib.parse.urlparse(url).path).suffix.lower()
    if suffix in {".png", ".jpg", ".jpeg", ".webp", ".gif"}:
        return suffix
    if content_type:
        return mimetypes.guess_extension(content_type.split(";")[0].strip()) or ".png"
    return ".png"


def download_image(url: str, output_dir: Path, stem: str, index: int, timeout: int) -> Path:
    request = urllib.request.Request(url, headers={"User-Agent": "gpt-image-2-generator/1.0"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        content_type = response.headers.get("Content-Type")
        extension = guess_download_extension(url, content_type)
        output_path = unique_path(output_dir / f"{stem}-{index}{extension}")
        output_path.write_bytes(response.read())
    return output_path


def save_image_values(values: list[str], output_dir: Path, stem: str, timeout: int) -> list[Path]:
    paths: list[Path] = []
    for index, value in enumerate(values, start=1):
        if value.startswith("data:image/"):
            paths.append(save_data_uri(value, output_dir, stem, index))
        else:
            paths.append(download_image(value, output_dir, stem, index, timeout))
    return paths


def generate_image(
    prompt: str,
    size: str = "1:1",
    quality: str = DEFAULT_QUALITY,
    image_refs: list[str] | None = None,
    n: int = 1,
    output_dir: str | Path | None = None,
    timeout: int = 300,
    initial_poll_delay: float = 10,
    poll_interval: float = 5,
    max_wait: float = 300,
) -> dict[str, Any]:
    prompt = prompt.strip()
    if not prompt:
        raise ImageGenerationError("Prompt is required")
    if size not in SUPPORTED_SIZES:
        raise ImageGenerationError(f"Unsupported size: {size}")
    if quality not in SUPPORTED_QUALITIES:
        raise ImageGenerationError(f"Unsupported quality: {quality}")
    if n < 1:
        raise ImageGenerationError("n must be >= 1")

    output_path = Path(output_dir) if output_dir else ROOT_DIR / "outputs"
    output_path.mkdir(parents=True, exist_ok=True)
    token = load_token()
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    stem = f"gpt-image-2-{timestamp}"
    api_size = resolve_size_value(size, quality)

    payload: dict[str, Any] = {
        "model": MODEL,
        "prompt": prompt,
        "n": n,
        "size": api_size,
    }
    refs = [ref.strip() for ref in (image_refs or []) if ref.strip()]
    request_type = "edit" if refs else "generation"
    if refs:
        image_files = [image_ref_to_input_file(ref, index, timeout) for index, ref in enumerate(refs, start=1)]
        response = request_multipart_json(build_edits_api_url(), token, payload, image_files, timeout=timeout)
    else:
        response = request_json("POST", build_generations_api_url(), token, payload, timeout=timeout)
    response_path = output_path / f"{stem}-response.json"
    save_json(response_path, response)

    image_paths: list[Path] = []
    revised_prompts: list[str] = []

    b64_items = extract_b64_items(response)
    if b64_items:
        for index, item in enumerate(b64_items, start=1):
            image_paths.append(save_b64_image(item["b64_json"], output_path, stem, index))
            if isinstance(item.get("revised_prompt"), str):
                revised_prompts.append(item["revised_prompt"])
        return {
            "images": [str(path) for path in image_paths],
            "response_path": str(response_path),
            "revised_prompts": revised_prompts,
            "request_type": request_type,
            "api_size": api_size,
            "quality": quality,
            "mode": "sync-b64",
        }

    image_values = extract_image_values(response)
    if image_values:
        image_paths = save_image_values(image_values, output_path, stem, timeout)
        return {
            "images": [str(path) for path in image_paths],
            "response_path": str(response_path),
            "revised_prompts": revised_prompts,
            "request_type": request_type,
            "api_size": api_size,
            "quality": quality,
            "mode": "sync-url",
        }

    task_id = extract_task_id(response)
    if not task_id:
        raise ImageGenerationError(f"Unexpected response. Saved raw response to {response_path}")

    time.sleep(initial_poll_delay)
    deadline = time.time() + max_wait
    last_task: dict[str, Any] | None = None
    while time.time() <= deadline:
        last_task = request_json("GET", build_task_url(task_id), token, timeout=timeout)
        status = get_task_status(last_task)
        if status == "completed":
            task_path = output_path / f"{stem}-task.json"
            save_json(task_path, last_task)

            b64_items = extract_b64_items(last_task)
            if b64_items:
                for index, item in enumerate(b64_items, start=1):
                    image_paths.append(save_b64_image(item["b64_json"], output_path, stem, index))
                    if isinstance(item.get("revised_prompt"), str):
                        revised_prompts.append(item["revised_prompt"])
            else:
                image_paths = save_image_values(extract_image_values(last_task), output_path, stem, timeout)

            if not image_paths:
                raise ImageGenerationError(f"Task completed but no image was found. Saved task response to {task_path}")
            return {
                "images": [str(path) for path in image_paths],
                "response_path": str(response_path),
                "task_response_path": str(task_path),
                "revised_prompts": revised_prompts,
                "request_type": request_type,
                "api_size": api_size,
                "quality": quality,
                "mode": "async-task",
            }
        if status == "failed":
            raise ImageGenerationError(get_task_error(last_task))
        time.sleep(poll_interval)

    if last_task is not None:
        task_path = output_path / f"{stem}-task-timeout.json"
        save_json(task_path, last_task)
        raise ImageGenerationError(f"Task polling timed out. Saved last task response to {task_path}")
    raise ImageGenerationError("Task polling timed out before the first task response")


def save_token(token: str) -> Path:
    raw = token.strip()
    if not raw:
        raise ImageGenerationError("Token cannot be empty")
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(
        f"# wuzuapi.com API token\n{normalize_token(raw)}\n",
        encoding="utf-8",
    )
    return TOKEN_FILE


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate images with GPT Image 2 via wuzuapi.com")
    parser.add_argument("--save-token", metavar="TOKEN", help="Save an API token to config/token.txt and exit")
    parser.add_argument("--prompt", required=False, default=None, help="Text prompt")
    parser.add_argument("--size", default="1:1", choices=SUPPORTED_SIZES, help="Aspect ratio")
    parser.add_argument("--quality", default=DEFAULT_QUALITY, choices=SUPPORTED_QUALITIES, help="Image quality")
    parser.add_argument("--n", default=1, type=int, help="Number of images")
    parser.add_argument("--image-ref", action="append", default=[], help="Reference image URL, data URI, or local path")
    parser.add_argument("--output-dir", default=str(ROOT_DIR / "outputs"), help="Output directory")
    parser.add_argument("--timeout", default=300, type=int, help="HTTP timeout in seconds")
    parser.add_argument("--initial-poll-delay", default=10, type=float, help="Seconds to wait before polling async tasks")
    parser.add_argument("--poll-interval", default=5, type=float, help="Async task poll interval in seconds")
    parser.add_argument("--max-wait", default=300, type=float, help="Maximum async task wait time in seconds")
    return parser


def main() -> int:
    args = build_parser().parse_args()

    if args.save_token:
        try:
            path = save_token(args.save_token)
            print(f"Token saved to {path}")
            return 0
        except Exception as error:
            print(f"ERROR: {error}", file=sys.stderr)
            return 1

    if not args.prompt:
        print("ERROR: --prompt is required (unless using --save-token)", file=sys.stderr)
        return 1

    try:
        result = generate_image(
            prompt=args.prompt,
            size=args.size,
            quality=args.quality,
            image_refs=args.image_ref,
            n=args.n,
            output_dir=args.output_dir,
            timeout=args.timeout,
            initial_poll_delay=args.initial_poll_delay,
            poll_interval=args.poll_interval,
            max_wait=args.max_wait,
        )
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

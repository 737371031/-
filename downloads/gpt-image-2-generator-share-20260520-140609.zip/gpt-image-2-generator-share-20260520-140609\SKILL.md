---
name: gpt-image-2-generator
description: Use this skill when the user wants to generate or edit images with GPT Image 2 through the wuzuapi.com API. Supports prompt-only generation and prompt plus optional image references from URL/base64/local files, supported aspect ratios, synchronous b64_json responses, asynchronous task polling, and a local web UI starter.
---

# GPT Image 2 生图

## 何时使用

当用户要求“生图”“改图”“参考图生成”“调用 GPT Image 2 生成图片”或启动本地网页生图工具时，使用本 skill。

本工具不区分“文生图 / 图生图 / 多图融合”等模式：始终传入 prompt；如果用户提供图片、图片链接或本地路径，就额外传入一个或多个 `--image-ref`。

## Token 配置

- Token 单独放在 `config/token.txt`，用户只需把第一行有效内容改成自己的 API token。
- 不要在 prompt、代码或聊天回复中暴露 token。
- 脚本会优先读取环境变量 `GPT_IMAGE_2_TOKEN`、`WUZUAPI_API_KEY`、`WUZUAPI_TOKEN`、`APICODEX_API_KEY`、`APICODEX_TOKEN`、`CODEX_API_KEY`、`OPENAI_API_KEY`，都没有时再读取 `config/token.txt`。

## Token 获取流程（重要）

当用户调用本 skill 时，按以下流程处理 Token：

1. **先直接尝试执行**：直接运行 `python scripts/generate_image.py --prompt ...`。脚本会自动从环境变量和 `config/token.txt` 中查找可用 Token，如果宿主平台（如 Claude Code、Codex CLI 等）已注入 API key 到环境变量，脚本会自动使用，无需任何额外操作。

2. **检测 Token 缺失**：如果脚本输出包含 `No usable token found`，说明环境变量和 `config/token.txt` 中都没有可用的 Token。此时 **必须** 向用户索要 API key：
   - 告诉用户：需要一个 wuzuapi.com 的 API Token 才能使用本功能。
   - 引导用户前往 https://wuzuapi.com 获取 API key。
   - 等待用户提供 key。

3. **保存 Token 并重试**：用户提供 key 后：
   - 执行 `python scripts/generate_image.py --save-token <用户提供的key>` 将 key 保存到 `config/token.txt`。
   - 然后重新执行原来的生图命令。

**注意**：绝对不要在聊天中直接显示或暴露用户提供的完整 Token。

## API 约定

- 纯文本生成接口：`POST https://wuzuapi.com/v1/images/generations`
- 带参考图接口：`POST https://wuzuapi.com/v1/images/edits`
- 模型固定：`gpt-image-2`。不要把配置 key 写到 `model` 字段里。
- 可选模型配置：`--model-config-key`，按站点模型列表返回的配置 key 填写。
- 鉴权头：`Authorization: Bearer <token>`
- 支持的 `size`：`1:1`、`16:9`、`9:16`、`4:3`、`3:4`、`3:2`、`2:3`、`5:4`、`4:5`、`2:1`、`1:2`、`21:9`、`9:21`
- 支持的 `quality`：`1k`、`2k`、`4k`，默认 `2k`。当前默认会把 `quality` 原样提交给 API，不再把比例强行改成像素尺寸。
- `n` 支持 `1-9`。固定尺寸可传 `--width` / `--height`；高清后处理目标可传 `--output-width` / `--output-height`。
- 按比例推导尺寸可传 `--aspect-ratio` / `--resolution`；返回格式可传 `--response-format b64_json` 或 `--response-format url`。
- 如需兼容旧版“比例 + 质量映射成像素 size”的行为，可额外加 `--map-size-to-pixels`。
- 参考图以 multipart 文件字段 `image[]` 提交。脚本会把图片 URL 下载为文件，把 `data:image/...;base64,...` 解码为文件，把本地图片路径读为文件。
- 不要再把参考图放进 `/v1/images/generations` 的 `image_urls` 字段；当前接口会忽略该字段，返回 usage 中的 `image_tokens` 仍为 0。

## CLI 用法

优先使用随 skill 提供的脚本，避免重复编写请求和轮询逻辑：

```powershell
python scripts/generate_image.py --prompt "一只橘猫坐在窗台看夕阳，水彩画风格" --size 16:9 --quality 2k
```

带一张或多张参考图：

```powershell
python scripts/generate_image.py --prompt "把参考图融合成复古海报" --size 4:3 --quality 4k --image-ref .\photo-a.png --image-ref https://example.com/photo-b.jpg
```

固定宽高或 4K 配置：

```powershell
python scripts/generate_image.py --prompt "高清产品海报" --model-config-key "gpt-image-2-[c4k]" --width 2880 --height 2880 --output-width 4096 --output-height 4096 --response-format url
```

默认输出到 `outputs/`，会同时保存原始 JSON 响应和解码后的图片。

## 网页工具

- 双击根目录的 `启动网页工具.bat` 即可启动本地网页。
- 默认地址是 `http://127.0.0.1:7862/`，服务只绑定本机。
- 网页调用服务端脚本读取环境变量或 `config/token.txt`，不会把 token 暴露给浏览器表单。

## 返回兼容

脚本必须同时处理两种返回：

- 同步：`data[0].b64_json`，直接 base64 解码保存图片。
- 异步：返回 `task_id` 或 `data.id` 后轮询 `/v1/tasks/{task_id}`，完成后读取 `data.result.images[0].url[0]` 并下载图片。

## 注意事项

- 单张图片请求可能较慢，默认请求超时为 `300s`。
- `size` 是比例参数；如果业务依赖固定像素，生成后应自行校验和裁切。
- 异步模式首次轮询建议等待 `10~20s`，之后每 `3~5s` 轮询一次，避免高频请求。

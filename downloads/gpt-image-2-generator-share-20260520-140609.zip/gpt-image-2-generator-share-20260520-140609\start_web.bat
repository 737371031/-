@echo off
setlocal
cd /d "%~dp0"

if not exist "config" mkdir "config"
if not exist "config\token.txt" (
  > "config\token.txt" echo # Put your wuzuapi.com API token on the next line, without Bearer.
  >> "config\token.txt" echo YOUR_API_TOKEN_HERE
)

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 "scripts\web_app.py" --open
  if %ERRORLEVEL% EQU 0 goto end
  echo py launcher failed, trying python...
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  python "scripts\web_app.py" --open
  goto end
)

echo Python 3 was not found. Please install Python 3 and run this file again.

:end
pause

@echo off
setlocal
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\export_share_package.ps1"
if errorlevel 1 (
  echo.
  echo Export failed. See the error message above.
) else (
  echo.
  echo Export finished. ZIP package is in the dist folder.
)
pause

﻿from __future__ import annotations

import argparse
import html
import io
import json
import mimetypes
import sys
import threading
import urllib.parse
import webbrowser
import zipfile
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
OUTPUT_DIR = ROOT_DIR / "outputs"
HISTORY_FILE = OUTPUT_DIR / "history.jsonl"
MAX_PREVIEW_STRING = 240
MAX_HISTORY_ITEMS = 20

if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import generate_image  # noqa: E402


HTML_PAGE = r"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>GPT Image 2 生图工具</title>
  <style>
    :root { color-scheme: dark; font-family: Inter, "Segoe UI", sans-serif; }
    * { box-sizing: border-box; }
    body { margin: 0; background: #0f172a; color: #e5e7eb; }
    main { max-width: 1180px; margin: 0 auto; padding: 28px 16px 56px; }
    .panel { background: rgba(15, 23, 42, .82); border: 1px solid #334155; border-radius: 18px; padding: 22px; box-shadow: 0 18px 60px rgba(0, 0, 0, .22); }
    .panel + .panel { margin-top: 18px; }
    h1, h2, h3 { margin: 0; }
    h1 { font-size: 30px; margin-bottom: 8px; }
    h2 { font-size: 22px; margin-bottom: 12px; }
    p { margin: 0; color: #94a3b8; line-height: 1.6; }
    label { display: block; margin: 16px 0 8px; font-weight: 700; }
    textarea, select, input { width: 100%; border: 1px solid #475569; border-radius: 12px; background: #020617; color: #f8fafc; padding: 12px; font: inherit; }
    textarea { min-height: 132px; resize: vertical; }
    .row { display: grid; grid-template-columns: 1fr 170px 120px 120px; gap: 14px; align-items: start; }
    .model-grid { display: grid; grid-template-columns: 1fr 170px; gap: 14px; align-items: start; }
    .readonly-field { border: 1px solid #475569; border-radius: 12px; background: #0f172a; color: #f8fafc; padding: 12px; min-height: 47px; display: flex; align-items: center; font-weight: 800; }
    .resolution-panel { margin-top: 16px; border: 1px solid #1d4ed8; border-radius: 16px; padding: 16px; background: linear-gradient(135deg, rgba(14, 165, 233, .12), rgba(30, 41, 59, .88)); }
    .resolution-grid { display: grid; grid-template-columns: 1.2fr 1fr 1fr; gap: 14px; align-items: start; }
    .resolution-note { margin-top: 12px; color: #bfdbfe; font-size: 13px; line-height: 1.7; }
    .resolution-note strong { color: #f8fafc; }
    .advanced-grid { display: grid; grid-template-columns: repeat(4, minmax(120px, 1fr)); gap: 14px; }
    .chips { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 12px; }
    .chip { margin: 0; padding: 8px 14px; border-radius: 999px; border: 1px solid #475569; background: #111827; color: #cbd5e1; cursor: pointer; }
    .toolbar { display: flex; flex-wrap: wrap; gap: 12px; align-items: center; margin-top: 16px; }
    .button, button { display: inline-flex; align-items: center; justify-content: center; gap: 8px; border: 0; border-radius: 999px; padding: 13px 22px; font-weight: 800; font-size: 14px; background: linear-gradient(135deg, #38bdf8, #818cf8); color: #020617; cursor: pointer; text-decoration: none; }
    .button.secondary, button.secondary { background: #1e293b; color: #e2e8f0; border: 1px solid #475569; }
    .button.ghost, button.ghost { background: transparent; color: #cbd5e1; border: 1px dashed #475569; }
    button:disabled { opacity: .55; cursor: wait; }
    .hint { margin-top: 8px; font-size: 13px; color: #94a3b8; }
    .status { white-space: pre-wrap; margin-top: 16px; color: #cbd5e1; min-height: 48px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 16px; margin-top: 20px; }
    .card, .history-item { border: 1px solid #334155; border-radius: 14px; padding: 12px; background: #020617; }
    .history-item + .history-item { margin-top: 14px; }
    .thumbs { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin-top: 14px; }
    img { width: 100%; height: auto; border-radius: 10px; display: block; background: #111827; }
    a { color: #7dd3fc; word-break: break-all; }
    code, pre { background: #111827; border-radius: 12px; }
    code { padding: 2px 6px; }
    pre { margin: 12px 0 0; padding: 14px; overflow: auto; white-space: pre-wrap; word-break: break-word; border: 1px solid #334155; }
    details { margin-top: 16px; border: 1px solid #334155; border-radius: 14px; padding: 12px 14px; background: #020617; }
    summary { cursor: pointer; font-weight: 750; color: #bfdbfe; }
    .section-title { display: flex; justify-content: space-between; gap: 12px; align-items: center; margin-bottom: 12px; }
    .meta { margin-top: 8px; color: #94a3b8; font-size: 13px; }
    .json-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .muted { color: #94a3b8; }
    .empty { color: #94a3b8; padding: 10px 0; }
    .inline-links { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 12px; }
    @media (max-width: 900px) {
      .row, .model-grid, .resolution-grid, .advanced-grid, .json-grid { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
<main>
  <section class="panel">
    <h1>GPT Image 2 生图工具</h1>
    <p>Token 从服务端 <code>config/token.txt</code> 读取，不会显示在网页里。输入 prompt，可选添加一张或多张参考图，服务端会自动选择纯文本生成或带图编辑。</p>

    <label for="prompt">Prompt</label>
    <textarea id="prompt" placeholder="例如：一只橘猫坐在窗台看夕阳，水彩画风格"></textarea>

    <div class="chips" id="exampleChips">
      <button type="button" class="chip" data-size="16:9" data-prompt="一只橘猫坐在窗台看夕阳，水彩画风格，电影感，暖色调">示例：橘猫夕阳</button>
      <button type="button" class="chip" data-size="9:16" data-prompt="中国古风少女站在竹林中，轻雾，插画风，高清细节">示例：古风竖图</button>
      <button type="button" class="chip" data-size="1:1" data-prompt="把参考图改成水彩插画风格，保留主体构图">示例：参考图改风格</button>
      <button type="button" class="chip" data-size="4:3" data-prompt="把参考图融合成一张复古海报，统一色调与光影">示例：多参考图海报</button>
    </div>

    <div class="model-grid">
      <div>
        <label>模型名称</label>
        <div class="readonly-field">gpt-image-2</div>
        <p class="hint">模型固定只传 <code>gpt-image-2</code>；4K 通过下面的分辨率字段控制。</p>
      </div>
      <div>
        <label for="responseFormat">返回格式</label>
        <select id="responseFormat">
          <option value="">自动</option>
          <option value="b64_json">b64_json</option>
          <option value="url">url</option>
        </select>
      </div>
    </div>

    <div class="row">
      <div>
        <label for="refs">参考图 URL / data URI（每行一个，可选）</label>
        <textarea id="refs" placeholder="https://example.com/photo.jpg"></textarea>
      </div>
      <div>
        <label for="size">比例</label>
        <select id="size">
          <option value="1:1">1:1 正方形</option>
          <option value="16:9" selected>16:9 横屏</option>
          <option value="9:16">9:16 竖屏</option>
          <option value="4:3">4:3 横图</option>
          <option value="3:4">3:4 竖图</option>
          <option value="3:2">3:2 横图</option>
          <option value="2:3">2:3 竖图</option>
          <option value="5:4">5:4 横图</option>
          <option value="4:5">4:5 竖图</option>
          <option value="2:1">2:1 宽屏</option>
          <option value="1:2">1:2 长竖图</option>
          <option value="21:9">21:9 超宽屏</option>
          <option value="9:21">9:21 超长竖图</option>
        </select>
      </div>
      <div>
        <label for="count">数量</label>
        <input id="count" type="number" min="1" max="9" value="1" />
      </div>
      <div>
        <label for="quality">质量</label>
        <select id="quality">
          <option value="1k">1k</option>
          <option value="2k" selected>2k</option>
          <option value="4k">4k</option>
        </select>
      </div>
    </div>

    <div class="resolution-panel">
      <h2>分辨率控制</h2>
      <p class="resolution-note"><strong>注意：</strong><code>quality=4k</code> 是画质档，不等于一定输出 4K 像素。这里会按 API 文档把实际分辨率字段一起传给接口。</p>
      <div class="resolution-grid">
        <div>
          <label for="resolutionMode">输出模式</label>
          <select id="resolutionMode">
            <option value="auto" selected>自动跟随质量档</option>
            <option value="long-edge">手动最长边 resolution</option>
            <option value="dimensions">手动宽高 width + height</option>
            <option value="raw">原样传入高级参数</option>
          </select>
        </div>
        <div>
          <label for="resolutionPreset">最长边预设</label>
          <select id="resolutionPreset">
            <option value="auto" selected>自动：1k/2k/4k</option>
            <option value="1024">1024</option>
            <option value="1536">1536</option>
            <option value="2048">2048</option>
            <option value="3840">3840</option>
            <option value="4096">4096</option>
            <option value="custom">使用下方 resolution</option>
          </select>
        </div>
        <div>
          <label for="targetPixels">固定宽高预设</label>
          <select id="targetPixels">
            <option value="auto" selected>自动按比例推导</option>
            <option value="1024">最长边 1024</option>
            <option value="2048">最长边 2048</option>
            <option value="3840">最长边 3840</option>
            <option value="4096">最长边 4096</option>
          </select>
        </div>
      </div>
      <p id="resolutionHint" class="resolution-note">当前会按质量档自动补 <code>aspect_ratio</code> 与 <code>resolution</code>；模型仍只传 <code>gpt-image-2</code>。</p>
    </div>

    <label for="files">本地参考图（可多选，可选）</label>
    <input id="files" type="file" accept="image/*" multiple />
    <div class="hint">本地图片会在浏览器中转换为 data URI 后提交给本机服务。</div>

    <details>
      <summary>高级参数：尺寸、超时和异步轮询</summary>
      <p class="hint">文档优先级：<code>width + height</code> 最高，其次是像素型 <code>size</code>，再是 <code>aspect_ratio + resolution</code>。上面的分辨率控制会自动填写这些字段；这里也可以手动覆盖。</p>
      <div class="advanced-grid">
        <div>
          <label for="width">width</label>
          <input id="width" type="number" min="1" placeholder="例如 2880" />
        </div>
        <div>
          <label for="height">height</label>
          <input id="height" type="number" min="1" placeholder="例如 2880" />
        </div>
        <div>
          <label for="outputWidth">output_width</label>
          <input id="outputWidth" type="number" min="1" placeholder="例如 4096" />
        </div>
        <div>
          <label for="outputHeight">output_height</label>
          <input id="outputHeight" type="number" min="1" placeholder="例如 4096" />
        </div>
        <div>
          <label for="aspectRatio">aspect_ratio</label>
          <input id="aspectRatio" placeholder="例如 16:9" />
        </div>
        <div>
          <label for="resolution">resolution</label>
          <input id="resolution" type="number" min="1" placeholder="例如 1536" />
        </div>
        <div>
          <label for="mapSizeToPixels">兼容旧版像素映射</label>
          <select id="mapSizeToPixels">
            <option value="false" selected>关闭，按比例传 size</option>
            <option value="true">开启，按质量转像素</option>
          </select>
        </div>
        <div>
          <label for="timeout">请求超时（秒）</label>
          <input id="timeout" type="number" min="30" max="600" value="300" />
        </div>
        <div>
          <label for="initialPollDelay">首次轮询等待（秒）</label>
          <input id="initialPollDelay" type="number" min="0" max="60" value="10" />
        </div>
        <div>
          <label for="pollInterval">轮询间隔（秒）</label>
          <input id="pollInterval" type="number" min="1" max="30" value="5" />
        </div>
        <div>
          <label for="maxWait">最长等待（秒）</label>
          <input id="maxWait" type="number" min="30" max="1800" value="300" />
        </div>
      </div>
    </details>

    <div class="toolbar">
      <button id="generate">开始生成</button>
      <a id="downloadAllCurrent" class="button secondary" href="#" hidden>下载本次全部图片</a>
      <button id="refreshHistory" type="button" class="secondary">刷新历史记录</button>
    </div>

    <div id="status" class="status"></div>
    <div id="result" class="grid"></div>
  </section>

  <section class="panel">
    <div class="section-title">
      <h2>JSON 详情面板</h2>
      <div class="inline-links">
        <a id="rawResponseLink" href="#" target="_blank" hidden>打开原始响应 JSON</a>
        <a id="rawTaskLink" href="#" target="_blank" hidden>打开任务 JSON</a>
      </div>
    </div>
    <p id="jsonTitle" class="muted">生成完成后，可在这里查看接口返回的 JSON 预览。</p>
    <div class="json-grid">
      <div>
        <h3>响应 JSON 预览</h3>
        <pre id="responsePreview">暂无</pre>
      </div>
      <div>
        <h3>任务 JSON 预览</h3>
        <pre id="taskPreview">暂无</pre>
      </div>
    </div>
  </section>

  <section class="panel">
    <div class="section-title">
      <h2>历史生成记录</h2>
      <span class="muted">显示最近 20 条</span>
    </div>
    <div id="historyList" class="empty">暂无历史记录</div>
  </section>
</main>
<script>
const state = { historyItems: [] };
const QUALITY_LONG_EDGE = { "1k": 1024, "2k": 2048, "4k": 4096 };

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function fileToDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function toJsonText(value) {
  if (!value) return "暂无";
  return JSON.stringify(value, null, 2);
}

function parseRatio(value) {
  const match = String(value || "").trim().match(/^(\d+)\s*:\s*(\d+)$/);
  if (!match) return null;
  const widthRatio = Number(match[1]);
  const heightRatio = Number(match[2]);
  if (!widthRatio || !heightRatio) return null;
  return { widthRatio, heightRatio };
}

function roundToMultiple(value, multiple = 8) {
  return Math.max(multiple, Math.round(value / multiple) * multiple);
}

function dimensionsFromRatio(ratio, longEdge) {
  const parsed = parseRatio(ratio);
  if (!parsed || !longEdge) return null;
  const { widthRatio, heightRatio } = parsed;
  if (widthRatio >= heightRatio) {
    return {
      width: longEdge,
      height: roundToMultiple(longEdge * heightRatio / widthRatio)
    };
  }
  return {
    width: roundToMultiple(longEdge * widthRatio / heightRatio),
    height: longEdge
  };
}

function getSelectedLongEdge() {
  const quality = document.querySelector("#quality").value;
  const preset = document.querySelector("#resolutionPreset").value;
  if (preset === "auto") return QUALITY_LONG_EDGE[quality] || 2048;
  if (preset === "custom") return optionalNumberValue("#resolution") || QUALITY_LONG_EDGE[quality] || 2048;
  return Number(preset);
}

function optionalNumberValue(selector) {
  const value = document.querySelector(selector).value.trim();
  return value ? Number(value) : null;
}

function optionalTextValue(selector) {
  const value = document.querySelector(selector).value.trim();
  return value || null;
}

function buildResolutionOptions() {
  const mode = document.querySelector("#resolutionMode").value;
  const size = document.querySelector("#size").value;
  const quality = document.querySelector("#quality").value;
  const options = {
    width: optionalNumberValue("#width"),
    height: optionalNumberValue("#height"),
    output_width: optionalNumberValue("#outputWidth"),
    output_height: optionalNumberValue("#outputHeight"),
    aspect_ratio: optionalTextValue("#aspectRatio"),
    resolution: optionalNumberValue("#resolution"),
    auto_resolution: true
  };

  if (mode === "raw") {
    options.auto_resolution = false;
    return options;
  }

  if (mode === "dimensions") {
    const preset = document.querySelector("#targetPixels").value;
    const longEdge = preset === "auto" ? getSelectedLongEdge() : Number(preset);
    const dims = dimensionsFromRatio(size, longEdge);
    if (dims) {
      options.width = options.width || dims.width;
      options.height = options.height || dims.height;
      if (quality === "4k") {
        options.output_width = options.output_width || dims.width;
        options.output_height = options.output_height || dims.height;
      }
    }
    options.resolution = null;
    return options;
  }

  const longEdge = getSelectedLongEdge();
  options.aspect_ratio = options.aspect_ratio || size;
  options.resolution = options.resolution || longEdge;
  return options;
}

function updateResolutionHint() {
  const mode = document.querySelector("#resolutionMode").value;
  const size = document.querySelector("#size").value;
  const quality = document.querySelector("#quality").value;
  const longEdge = getSelectedLongEdge();
  const dims = dimensionsFromRatio(size, longEdge);
  const hint = document.querySelector("#resolutionHint");
  if (mode === "raw") {
    hint.innerHTML = "当前为原样传入：只发送高级参数里已经填写的字段，不自动补分辨率。";
  } else if (mode === "dimensions" && dims) {
    hint.innerHTML = `当前会按 <code>${size}</code> 推导固定宽高：<code>width=${dims.width}</code>、<code>height=${dims.height}</code>；模型仍只传 <code>gpt-image-2</code>。`;
  } else {
    hint.innerHTML = `当前会发送 <code>aspect_ratio=${size}</code>、<code>resolution=${longEdge}</code>；模型仍只传 <code>gpt-image-2</code>。`;
  }
}

function buildDownloadAllUrl(images) {
  const names = (images || []).map(item => item.name).filter(Boolean);
  return names.length ? `/api/download-all?names=${encodeURIComponent(names.join(","))}` : "#";
}

function describeRequestPayload(payload) {
  if (!payload) return "无";
  const keys = [
    "size",
    "quality",
    "width",
    "height",
    "output_width",
    "output_height",
    "aspect_ratio",
    "resolution",
    "response_format"
  ];
  return keys
    .filter(key => payload[key] !== undefined && payload[key] !== null && payload[key] !== "")
    .map(key => `${key}=${payload[key]}`)
    .join(" / ") || "无";
}

function updateDownloadButton(images) {
  const button = document.querySelector("#downloadAllCurrent");
  const url = buildDownloadAllUrl(images);
  if (url === "#") {
    button.hidden = true;
    button.removeAttribute("href");
    return;
  }
  button.hidden = false;
  button.href = url;
}

function showJsonDetails(title, responsePreview, taskPreview, responseFile, taskFile) {
  document.querySelector("#jsonTitle").textContent = title || "JSON 详情";
  document.querySelector("#responsePreview").textContent = toJsonText(responsePreview);
  document.querySelector("#taskPreview").textContent = toJsonText(taskPreview);

  const responseLink = document.querySelector("#rawResponseLink");
  if (responseFile && responseFile.url) {
    responseLink.hidden = false;
    responseLink.href = responseFile.url;
  } else {
    responseLink.hidden = true;
    responseLink.removeAttribute("href");
  }

  const taskLink = document.querySelector("#rawTaskLink");
  if (taskFile && taskFile.url) {
    taskLink.hidden = false;
    taskLink.href = taskFile.url;
  } else {
    taskLink.hidden = true;
    taskLink.removeAttribute("href");
  }
}

function renderResult(data) {
  const result = document.querySelector("#result");
  const images = data.images || [];
  if (!images.length) {
    result.innerHTML = '<div class="empty">本次没有返回可展示的图片。</div>';
  } else {
    result.innerHTML = images.map(image => `
      <div class="card">
        <a href="${image.url}" target="_blank"><img src="${image.url}" alt="generated image"></a>
        <div class="meta">${escapeHtml(image.name)}</div>
        ${image.width && image.height ? `<div class="meta">实际像素：${escapeHtml(image.width)} × ${escapeHtml(image.height)}</div>` : ""}
        <div class="inline-links">
          <a href="${image.url}" download>下载图片</a>
          <a href="${image.url}" target="_blank">新窗口打开</a>
        </div>
      </div>
    `).join("");
  }

  updateDownloadButton(images);
  showJsonDetails(
    `本次生成：${data.model || "gpt-image-2"} / ${data.request_mode} / ${data.request_type || "unknown"} / ${data.mode} / ${describeRequestPayload(data.request_payload)}`,
    data.response_preview,
    data.task_response_preview,
    data.response_file,
    data.task_response_file,
  );
}

function renderHistory(items) {
  state.historyItems = items || [];
  const list = document.querySelector("#historyList");
  if (!state.historyItems.length) {
    list.className = "empty";
    list.textContent = "暂无历史记录";
    return;
  }

  list.className = "";
  list.innerHTML = state.historyItems.map((item, index) => {
    const thumbs = (item.images || []).map(image => `
      <a href="${image.url}" target="_blank">
        <img src="${image.url}" alt="history image">
        ${image.width && image.height ? `<span class="meta">实际像素：${escapeHtml(image.width)} × ${escapeHtml(image.height)}</span>` : ""}
      </a>
    `).join("");
    const downloadLink = buildDownloadAllUrl(item.images || []);
    return `
      <div class="history-item">
        <h3>${escapeHtml(item.prompt || "未命名 prompt")}</h3>
        <div class="meta">${escapeHtml(item.created_at || "")} · 模型 ${escapeHtml(item.model || "gpt-image-2")} · 输入 ${escapeHtml(item.request_mode || "")} · 接口 ${escapeHtml(item.request_type || "")} · 返回模式 ${escapeHtml(item.result_mode || "")} · ${escapeHtml(describeRequestPayload(item.request_payload))}</div>
        <div class="meta">数量 ${escapeHtml(item.n || 0)} · 参考图 ${escapeHtml(item.ref_count || 0)} 张</div>
        <div class="toolbar">
          <button type="button" class="secondary history-json" data-index="${index}">查看 JSON</button>
          ${downloadLink === "#" ? "" : `<a class="button secondary" href="${downloadLink}">下载该次全部图片</a>`}
        </div>
        ${thumbs ? `<div class="thumbs">${thumbs}</div>` : '<div class="empty">该记录暂无可展示图片</div>'}
      </div>
    `;
  }).join("");

  list.querySelectorAll(".history-json").forEach(button => {
    button.addEventListener("click", () => {
      const index = Number(button.dataset.index);
      const item = state.historyItems[index];
      showJsonDetails(
        `历史记录：${item.prompt || "未命名 prompt"}`,
        item.response_preview,
        item.task_response_preview,
        item.response_file,
        item.task_response_file,
      );
    });
  });
}

async function refreshHistory() {
  const response = await fetch("/api/history");
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error(data.error || "读取历史失败");
  renderHistory(data.items || []);
}

async function generate() {
  const button = document.querySelector("#generate");
  const status = document.querySelector("#status");
  button.disabled = true;
  document.querySelector("#result").innerHTML = "";
  status.textContent = "正在提交请求，请等待……";

  try {
    const prompt = document.querySelector("#prompt").value.trim();
    const textRefs = document.querySelector("#refs").value.split(/\r?\n/).map(v => v.trim()).filter(Boolean);
    const fileRefs = await Promise.all([...document.querySelector("#files").files].map(fileToDataURL));
    const allRefs = [...textRefs, ...fileRefs];

    if (!prompt) throw new Error("请输入 prompt");
    const resolutionOptions = buildResolutionOptions();

    const response = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt,
        size: document.querySelector("#size").value,
        quality: document.querySelector("#quality").value,
        ...resolutionOptions,
        response_format: optionalTextValue("#responseFormat"),
        map_size_to_pixels: document.querySelector("#mapSizeToPixels").value === "true",
        n: Number(document.querySelector("#count").value || 1),
        image_refs: allRefs,
        timeout: Number(document.querySelector("#timeout").value || 300),
        initial_poll_delay: Number(document.querySelector("#initialPollDelay").value || 10),
        poll_interval: Number(document.querySelector("#pollInterval").value || 5),
        max_wait: Number(document.querySelector("#maxWait").value || 300)
      })
    });

    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || "生成失败");

    status.textContent = `完成：${data.mode}\n模型：${data.model || "gpt-image-2"}\n输入：${data.request_mode}\n接口：${data.request_type || "unknown"}\n请求尺寸：${describeRequestPayload(data.request_payload)}\nJSON：${data.response_file ? data.response_file.name : '无'}`;
    if (data.task_response_file) {
      status.textContent += `\nTask JSON：${data.task_response_file.name}`;
    }
    if (data.revised_prompts && data.revised_prompts.length) {
      status.textContent += `\nRevised prompt：${data.revised_prompts.join("\n")}`;
    }

    renderResult(data);
    await refreshHistory();
  } catch (error) {
    updateDownloadButton([]);
    status.textContent = `错误：${error.message}`;
  } finally {
    button.disabled = false;
  }
}

document.querySelector("#generate").addEventListener("click", generate);
document.querySelector("#refreshHistory").addEventListener("click", async () => {
  try {
    await refreshHistory();
  } catch (error) {
    document.querySelector("#status").textContent = `错误：${error.message}`;
  }
});

document.querySelectorAll("#exampleChips .chip").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelector("#prompt").value = button.dataset.prompt || "";
    document.querySelector("#size").value = button.dataset.size || "16:9";
    updateResolutionHint();
  });
});

[
  "#resolutionMode",
  "#resolutionPreset",
  "#targetPixels",
  "#size",
  "#quality",
  "#resolution",
  "#width",
  "#height",
  "#outputWidth",
  "#outputHeight",
  "#aspectRatio"
].forEach(selector => {
  document.querySelector(selector).addEventListener("input", updateResolutionHint);
  document.querySelector(selector).addEventListener("change", updateResolutionHint);
});

updateResolutionHint();
refreshHistory().catch(error => {
  document.querySelector("#status").textContent = `历史记录加载失败：${error.message}`;
});
</script>
</body>
</html>
"""


def json_bytes(data: dict[str, Any]) -> bytes:
    return json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")


def ensure_output_dir() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def safe_output_path(name: str) -> Path:
    candidate = OUTPUT_DIR / Path(name).name
    resolved = candidate.resolve()
    output_root = OUTPUT_DIR.resolve()
    if resolved.parent != output_root:
        raise ValueError("invalid file name")
    return resolved


def build_file_meta(path_value: str | Path | None) -> dict[str, Any] | None:
    if not path_value:
        return None
    path = Path(path_value)
    name = path.name
    meta = {
        "name": name,
        "path": str(path),
        "url": f"/outputs/{urllib.parse.quote(name)}",
    }
    dimensions = read_image_dimensions(path)
    if dimensions:
        meta["width"] = dimensions[0]
        meta["height"] = dimensions[1]
    return meta


def read_image_dimensions(path: Path) -> tuple[int, int] | None:
    try:
        data = path.read_bytes()[:4096]
    except OSError:
        return None

    if len(data) >= 24 and data.startswith(b"\x89PNG\r\n\x1a\n"):
        return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")

    if len(data) >= 30 and data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        chunk = data[12:16]
        if chunk == b"VP8X" and len(data) >= 30:
            width = int.from_bytes(data[24:27], "little") + 1
            height = int.from_bytes(data[27:30], "little") + 1
            return width, height
        if chunk == b"VP8 " and len(data) >= 30:
            width = int.from_bytes(data[26:28], "little") & 0x3FFF
            height = int.from_bytes(data[28:30], "little") & 0x3FFF
            return width, height
        if chunk == b"VP8L" and len(data) >= 25:
            b0, b1, b2, b3 = data[21], data[22], data[23], data[24]
            width = 1 + (((b1 & 0x3F) << 8) | b0)
            height = 1 + (((b3 & 0x0F) << 10) | (b2 << 2) | ((b1 & 0xC0) >> 6))
            return width, height

    if len(data) >= 4 and data[:2] == b"\xff\xd8":
        try:
            with path.open("rb") as handle:
                handle.read(2)
                while True:
                    marker_start = handle.read(1)
                    if not marker_start:
                        return None
                    if marker_start != b"\xff":
                        continue
                    marker = handle.read(1)
                    while marker == b"\xff":
                        marker = handle.read(1)
                    if not marker or marker in {b"\xd8", b"\xd9"}:
                        continue
                    length_bytes = handle.read(2)
                    if len(length_bytes) != 2:
                        return None
                    segment_length = int.from_bytes(length_bytes, "big")
                    if segment_length < 2:
                        return None
                    if marker[0] in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
                        segment = handle.read(5)
                        if len(segment) != 5:
                            return None
                        height = int.from_bytes(segment[1:3], "big")
                        width = int.from_bytes(segment[3:5], "big")
                        return width, height
                    handle.seek(segment_length - 2, 1)
        except OSError:
            return None

    return None


def sanitize_for_preview(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: sanitize_for_preview(item) for key, item in value.items()}
    if isinstance(value, list):
        if len(value) > 20:
            trimmed = value[:20]
            return [sanitize_for_preview(item) for item in trimmed] + [f"... truncated {len(value) - 20} more items"]
        return [sanitize_for_preview(item) for item in value]
    if isinstance(value, str) and len(value) > MAX_PREVIEW_STRING:
        return f"{value[:MAX_PREVIEW_STRING]}... <truncated {len(value) - MAX_PREVIEW_STRING} chars>"
    return value


def load_json_preview(path_value: str | Path | None) -> Any | None:
    if not path_value:
        return None
    path = Path(path_value)
    if not path.exists():
        return None
    try:
        return sanitize_for_preview(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        return None


def append_history(item: dict[str, Any]) -> None:
    ensure_output_dir()
    with HISTORY_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(item, ensure_ascii=False) + "\n")


def load_history(limit: int = MAX_HISTORY_ITEMS) -> list[dict[str, Any]]:
    if not HISTORY_FILE.exists():
        return []
    items: list[dict[str, Any]] = []
    for line in HISTORY_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            items.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return list(reversed(items[-limit:]))


def build_history_entry(
    request_mode: str,
    prompt: str,
    model: str,
    size: str,
    quality: str,
    api_size: str,
    n: int,
    ref_count: int,
    images: list[dict[str, str]],
    result: dict[str, Any],
    response_preview: Any | None,
    task_response_preview: Any | None,
) -> dict[str, Any]:
    return {
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "request_mode": request_mode,
        "request_type": result.get("request_type"),
        "result_mode": result.get("mode"),
        "model": model,
        "prompt": prompt,
        "size": size,
        "quality": quality,
        "api_size": api_size,
        "request_payload": result.get("request_payload"),
        "n": n,
        "ref_count": ref_count,
        "images": images,
        "response_file": build_file_meta(result.get("response_path")),
        "task_response_file": build_file_meta(result.get("task_response_path")),
        "response_preview": response_preview,
        "task_response_preview": task_response_preview,
    }


class WebHandler(BaseHTTPRequestHandler):
    server_version = "GPTImage2Web/2.0"

    def log_message(self, format: str, *args: Any) -> None:
        print(f"{self.address_string()} - {format % args}")

    def send_body(self, status: int, body: bytes, content_type: str, extra_headers: dict[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if extra_headers:
            for key, value in extra_headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, status: int, data: dict[str, Any]) -> None:
        self.send_body(status, json_bytes(data), "application/json; charset=utf-8")

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path in {"/", "/index.html"}:
            self.send_body(200, HTML_PAGE.encode("utf-8"), "text/html; charset=utf-8")
            return
        if parsed.path == "/health":
            self.send_json(200, {"ok": True, "api_base_url": generate_image.get_api_base_url()})
            return
        if parsed.path == "/api/history":
            self.handle_history(parsed.query)
            return
        if parsed.path == "/api/download-all":
            self.handle_download_all(parsed.query)
            return
        if parsed.path.startswith("/outputs/"):
            self.serve_output(parsed.path)
            return
        self.send_json(404, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/api/generate":
            self.send_json(404, {"ok": False, "error": "not found"})
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length > 80 * 1024 * 1024:
                self.send_json(413, {"ok": False, "error": "request too large"})
                return

            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            prompt = str(payload.get("prompt", "")).strip()
            model = generate_image.DEFAULT_MODEL
            size = str(payload.get("size", "16:9"))
            quality = str(payload.get("quality", generate_image.DEFAULT_QUALITY))
            n = int(payload.get("n", 1))
            width = payload.get("width")
            height = payload.get("height")
            output_width = payload.get("output_width")
            output_height = payload.get("output_height")
            aspect_ratio = payload.get("aspect_ratio")
            resolution = payload.get("resolution")
            response_format = payload.get("response_format")
            auto_resolution = bool(payload.get("auto_resolution", True))
            map_size_to_pixels = bool(payload.get("map_size_to_pixels", False))
            image_refs = [str(item) for item in payload.get("image_refs", []) if str(item).strip()]
            request_mode = "prompt+images" if image_refs else "prompt-only"

            if not prompt:
                raise ValueError("请输入 prompt")

            result = generate_image.generate_image(
                prompt=prompt,
                size=size,
                quality=quality,
                width=int(width) if width else None,
                height=int(height) if height else None,
                output_width=int(output_width) if output_width else None,
                output_height=int(output_height) if output_height else None,
                aspect_ratio=str(aspect_ratio).strip() if aspect_ratio else None,
                resolution=int(resolution) if resolution else None,
                response_format=str(response_format).strip() if response_format else None,
                auto_resolution=auto_resolution,
                map_size_to_pixels=map_size_to_pixels,
                n=n,
                image_refs=image_refs,
                output_dir=OUTPUT_DIR,
                timeout=int(payload.get("timeout", 300)),
                initial_poll_delay=float(payload.get("initial_poll_delay", 10)),
                poll_interval=float(payload.get("poll_interval", 5)),
                max_wait=float(payload.get("max_wait", 300)),
            )
        except generate_image.UpstreamHTTPError as error:
            self.send_json(error.status_code, {"ok": False, "error": str(error)})
            return
        except (ValueError, generate_image.ImageGenerationError) as error:
            self.send_json(400, {"ok": False, "error": str(error)})
            return
        except Exception as error:
            self.send_json(500, {"ok": False, "error": str(error)})
            return

        images = [build_file_meta(path) for path in result.get("images", [])]
        images = [item for item in images if item is not None]
        response_preview = load_json_preview(result.get("response_path"))
        task_response_preview = load_json_preview(result.get("task_response_path"))
        history_entry = build_history_entry(
            request_mode=request_mode,
            prompt=prompt,
            model=str(result.get("model", model)),
            size=size,
            quality=quality,
            api_size=str(result.get("api_size", "")),
            n=n,
            ref_count=len(image_refs),
            images=images,
            result=result,
            response_preview=response_preview,
            task_response_preview=task_response_preview,
        )
        append_history(history_entry)

        self.send_json(200, {
            "ok": True,
            "request_mode": request_mode,
            "request_type": result.get("request_type"),
            "mode": result.get("mode"),
            "model": result.get("model", model),
            "size": size,
            "quality": quality,
            "api_size": result.get("api_size"),
            "request_payload": result.get("request_payload"),
            "n": n,
            "images": images,
            "response_file": build_file_meta(result.get("response_path")),
            "task_response_file": build_file_meta(result.get("task_response_path")),
            "response_preview": response_preview,
            "task_response_preview": task_response_preview,
            "revised_prompts": result.get("revised_prompts", []),
        })

    def handle_history(self, query: str) -> None:
        params = urllib.parse.parse_qs(query)
        try:
            limit = int(params.get("limit", [str(MAX_HISTORY_ITEMS)])[0])
        except ValueError:
            limit = MAX_HISTORY_ITEMS
        limit = max(1, min(limit, 100))
        self.send_json(200, {"ok": True, "items": load_history(limit)})

    def handle_download_all(self, query: str) -> None:
        params = urllib.parse.parse_qs(query)
        raw_names = params.get("names", [""])[0]
        names = [Path(name).name for name in raw_names.split(",") if name.strip()]
        if not names:
            self.send_json(400, {"ok": False, "error": "no image names provided"})
            return

        try:
            paths = [safe_output_path(name) for name in names]
        except ValueError as error:
            self.send_json(400, {"ok": False, "error": str(error)})
            return

        existing = [path for path in paths if path.exists() and path.is_file()]
        if not existing:
            self.send_json(404, {"ok": False, "error": "no output files found"})
            return

        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
            for path in existing:
                archive.write(path, arcname=path.name)
        body = buffer.getvalue()
        filename = f"gpt-image-2-bundle-{datetime.now().strftime('%Y%m%d-%H%M%S')}.zip"
        self.send_body(
            200,
            body,
            "application/zip",
            {
                "Content-Disposition": f'attachment; filename="{filename}"',
            },
        )

    def serve_output(self, request_path: str) -> None:
        name = Path(urllib.parse.unquote(request_path.removeprefix("/outputs/"))).name
        try:
            resolved = safe_output_path(name)
            if not resolved.exists() or not resolved.is_file():
                self.send_json(404, {"ok": False, "error": "output not found"})
                return
            content_type = mimetypes.guess_type(str(resolved))[0] or "application/octet-stream"
            self.send_body(200, resolved.read_bytes(), content_type)
        except Exception as error:
            self.send_json(500, {"ok": False, "error": html.escape(str(error))})


def main() -> int:
    parser = argparse.ArgumentParser(description="Start the GPT Image 2 local web UI")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=7862, type=int)
    parser.add_argument("--open", action="store_true", help="Open browser after startup")
    args = parser.parse_args()

    ensure_output_dir()
    server = ThreadingHTTPServer((args.host, args.port), WebHandler)
    url = f"http://{args.host}:{args.port}/"
    print(f"GPT Image 2 web tool is running: {url}")
    print(f"Token file: {generate_image.TOKEN_FILE}")
    print(f"API base: {generate_image.get_api_base_url()}")
    print("Press Ctrl+C to stop.")
    if args.open:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
